create definer = root@localhost trigger after_purchase
    after insert
    on purchase
    for each row
begin
    declare original_quantity int;
    declare remain_quantity int;
    declare point decimal(10,2);
    set original_quantity=(select quantity from goods where goods_id=new.goods_id);
    set remain_quantity=(original_quantity-new.quantity);
    update goods set quantity=remain_quantity where goods_id=new.goods_id;
    set point=new.payment;
    insert into customer_point(customer_id,get_point,way) values (new.customer_id,point,1);
end;

