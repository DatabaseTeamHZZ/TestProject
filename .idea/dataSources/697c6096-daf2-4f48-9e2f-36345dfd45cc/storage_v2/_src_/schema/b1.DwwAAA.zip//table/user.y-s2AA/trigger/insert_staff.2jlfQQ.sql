create definer = root@localhost trigger insert_staff
    after insert
    on user
    for each row
begin
    if(new.user_type=2) then insert into cashier(id) values(new.id);
    end if;
    if(new.user_type=3) then insert into buyer(id) values(new.id);
    end if;
end;

