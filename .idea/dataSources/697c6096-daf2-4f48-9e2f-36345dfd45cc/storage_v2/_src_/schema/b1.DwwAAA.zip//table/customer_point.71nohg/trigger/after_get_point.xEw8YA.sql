create definer = root@localhost trigger after_get_point
    after insert
    on customer_point
    for each row
begin
    declare origin_point decimal(10,2);
    declare new_point decimal(10,2);
    declare new_vip int;
    set origin_point=(select point from customer where customer_id=new.customer_id);
    set new_point=(origin_point+new.get_point);
    update customer set point=new_point where customer_id=new.customer_id;
    set new_vip=0;
    if(new_point>=1000 and new_point<3000) then set new_vip=1;end if;
    if(new_point>=3000 and new_point<5000) then set new_vip=2;end if;
    if(new_point>=5000 and new_point<10000) then set new_vip=3;end if;
    if(new_point>=10000 and new_point<20000) then set new_vip=4;end if;
    if(new_point>=20000) then set new_vip=5;end if;
    update customer set vip=new_vip where customer_id=new.customer_id;
end;

