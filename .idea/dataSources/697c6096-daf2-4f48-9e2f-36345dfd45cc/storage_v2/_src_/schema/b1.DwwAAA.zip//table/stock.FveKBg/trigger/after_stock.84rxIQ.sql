create definer = root@localhost trigger after_stock
    after insert
    on stock
    for each row
begin
    declare origin_quantity int;
    declare new_quantity int;
    set origin_quantity=(select quantity from goods where goods_id=new.goods_id);
    set new_quantity=origin_quantity+new.quantity;
    update goods set quantity=new_quantity where goods_id=new.goods_id;
end;

